/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdio.h>
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "peripheral/port/plib_port.h"

/* Macro definitions */

#define TRANSFER_SIZE 1
#define TRANSFER_SIZE_WORD 4

#define NUM_FRAMES_TO_CAPTURE 10

#define IMG_WIDTH       160
#define IMG_HEIGHT      120
#define LINE_BYTES      (IMG_WIDTH*2)    // 1 byte per pixel, Y-only
#define FRAME_BYTES     (IMG_WIDTH * IMG_HEIGHT *2) 


__attribute__ ((aligned (32))) uint8_t srcBuffer[TRANSFER_SIZE] = {0};
__attribute__ ((aligned (32))) uint8_t dstBuffer[TRANSFER_SIZE] = {0};

__attribute__ ((aligned (32))) uint32_t srcBuffer_2[TRANSFER_SIZE] = {0};
__attribute__ ((aligned (32))) uint32_t dstBuffer_2[TRANSFER_SIZE] = {0};

volatile bool frame_capture_active = false;
volatile bool frame_ready = false;
volatile uint8_t capture_count = 0;

volatile uint32_t line_index = 0;
volatile bool dmaLineActive = false;
volatile bool dmaLineDone = false;

extern uint8_t panda_scaled_data[38400];

#define SRC_PORT_ADDR ((const void *)((uint8_t *)&PORT_REGS->GROUP[2].PORT_IN + 1)) // keep +1 if that reads correct bits
static uint8_t frame_buffer[FRAME_BYTES] __attribute__((aligned(32))); // align for cache


volatile bool dmaXferDone = false;
volatile bool dmaXferError = false;
volatile uint32_t start_time = 0;
volatile uint32_t stop_time = 0;


void DMA_EventHandler(DMA_TRANSFER_EVENT event, uintptr_t context)
{

    if (event == DMA_TRANSFER_EVENT_BLOCK_TRANSFER_COMPLETE) {
        dmaLineDone = true;
        dmaLineActive = false;
        frame_ready = true;

    } else if (event == DMA_TRANSFER_EVENT_ERROR) {
        // handle error (reset DMA etc.)
        dmaLineActive = false;
    }
}


void HSYNC_ISR(void)
{

  line_index++;

}



void VSYNC_ISR(void)
{

    if (line_index >= (IMG_HEIGHT-5)) {
      DMA_ChannelDisable(DMA_CHANNEL_1);        
    // Depending on VSYNC polarity: capture on rising or falling. Use the edge you configured.
    DMA_ChannelTransfer(DMA_CHANNEL_1, (const void *)((uint8_t *)&PORT_REGS->GROUP[2].PORT_IN+1), &panda_scaled_data[0], FRAME_BYTES);

    line_index = 0;
    frame_capture_active = true;
    frame_ready = false;
    }
   // CLEAR_VSYNC_INTERRUPT_FLAG();
}

void send_frame(void)
{
    printf("FRAME_START\n");   // simple marker for PC side

    for (uint32_t i = 0; i < FRAME_BYTES; i++) {
        while (!SERCOM4_USART_TransmitterIsReady());           // wait for TX ready
        SERCOM4_USART_Write(&frame_buffer[i],1);     // send byte
       // printf("%02X ", frame_buffer[i]);
    }

    printf("FRAME_END\n");     // optional end marker
}


void I2C_Write(uint8_t reg_ad,uint8_t reg_value)
{
    uint8_t read_reg;
    uint8_t writeData[2];
    writeData[0] = reg_ad;
    writeData[1] = reg_value;
    while(SERCOM5_I2C_IsBusy());
    SERCOM5_I2C_Write((0x21),writeData, 2);
//    while(SERCOM5_I2C_IsBusy());
//    SERCOM5_I2C_Write((0x42 >> 1),&reg_value, 1);
    while(SERCOM5_I2C_IsBusy());
    
    SERCOM5_I2C_Write((0x21),&reg_ad, 1);
    while(SERCOM5_I2C_IsBusy());
    SERCOM5_I2C_Read((0x21),&read_reg, 1);
    while(SERCOM5_I2C_IsBusy());
    (read_reg == reg_value)? printf("Write success : add - %x, val - %x\n\r",reg_ad,reg_value) : printf("Unsuccessful : add - %x, write - %x, read - %x\n\r",reg_ad, reg_value, read_reg);
//    (read_reg == re)            
}
void I2C_Read(uint8_t reg_ad)
{
    uint8_t read_reg;

    while(SERCOM5_I2C_IsBusy());
    
    SERCOM5_I2C_Write((0x43 >> 1),&reg_ad, 1);
    while(SERCOM5_I2C_IsBusy());
    SERCOM5_I2C_Read((0x43 >> 1),&read_reg, 1);
    while(SERCOM5_I2C_IsBusy());
    printf("Read success : add - %x, val - %x\n\r",reg_ad,read_reg);
//    (read_reg == re)            
}

// void processCompletion(void)
// {
//     if (dmaLineDone) {
//         dmaLineDone = false;

//         // advance to next line
//         line_index++;

//         if (line_index >= IMG_HEIGHT) {
//             // finished full frame
//             frame_capture_active = false;
//             frame_ready = true;
            
//           //  printf("Captured Frame\r\n");
//              capture_count++;

//             if (capture_count >= NUM_FRAMES_TO_CAPTURE) {
//               legato_showScreen(screenID_Screen0);
//           //       /* Enable the EIC */
//           //       EIC_REGS->EIC_CTRLA &= ~EIC_CTRLA_ENABLE_Msk;

//           //       while((EIC_REGS->EIC_SYNCBUSY & EIC_SYNCBUSY_ENABLE_Msk) == EIC_SYNCBUSY_ENABLE_Msk)
//           //       {
//           //           /* Wait for sync */
//           //       }

//           //   //    memcpy((void*)panda_scaled_data , (void*)frame_buffer, FRAME_BYTES);  

//           //  //    legato_showScreen(screenID_Screen0);

//           //  //     send_frame();
          
//              }
            

//             // Optionally invalidate final cache or clean, depending on how you will use frame_buffer
//             // DCACHE_CLEAN_BY_ADDR((uint32_t *)frame_buffer, FRAME_BYTES);
//         }
//     }
// }



void ov7670_set_rgb565_QQVGA_Working(void)
{
  // Reset
I2C_Write(0x12, 0x80);
for(volatile int i=0; i<100000; i++);  // delay
for(volatile int i=0; i<100000; i++);  // delay
for(volatile int i=0; i<100000; i++);  // delay
for(volatile int i=0; i<100000; i++);  // delay



// Color settings, recommended defaults
I2C_Write(0x11, 0x81);   // CLKRC: Prescaler /4 (slower PCLK, easier for MCU)
I2C_Write(0x3A, 0x08);   // TSLB: Set correct RGB order
I2C_Write(0x3D, 0x88);   // TSLB: Set correct RGB order



I2C_Write(0x12, 0x14);   // COM7: RGB + QVGA scaling enabled
I2C_Write(0x8C, 0x00);   // RGB444: Off

I2C_Write(0xA2, 0x04);   // PCLK automatic


// RGB565 format
I2C_Write(0x40, 0xD0);   // COM15: Full range, RGB565

    // ----- SYNC & SIGNAL POLARITY -----
    I2C_Write(0x15, 0x20);     // COM10: PCLK only at active href

// No manual scaling
I2C_Write(0x0C, 0x0C);   // COM3: No DCW scaling here
 I2C_Write(0x3E, 0x12);  // COM14: Normal PCLK

I2C_Write(0x09, 0x03); // output drive capability


// QQVGA SCALING (160x120)
I2C_Write(0x70, 0x3F);   // SCALING_DCWCTR: Downsample 4x
I2C_Write(0x71, 0x35);   // SCALING_PCLK_DIV: Divide pixel clock
I2C_Write(0x72, 0x21);   // SCALING_XSC
I2C_Write(0x73, 0xF0);   // SCALING_YSC

// Windowing (centering the image)
I2C_Write(0x17, 0x16);   // HSTART
I2C_Write(0x18, 0x04);   // HSTOP
I2C_Write(0x32, 0xA4);   // HREF
I2C_Write(0x19, 0x02);   // VSTART
I2C_Write(0x1A, 0x7A);   // VSTOP
I2C_Write(0x03, 0x0A);   // VREF

// Auto-exposure/white balance default
 I2C_Write(0x13, 0x81);   // COM8: AEC, AGC, AWB ON

}

// void ov7670_set_rgb565_QQVGA(void)
// {
//     RST_OV_Clear();
//     for(volatile int i=0; i<100000; i++);  // delay
//     RST_OV_Set();

//     // Reset sensor
//     I2C_Write(0x12, 0x80);
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay

//     // RGB + QVGA base mode
//     I2C_Write(0x12, 0x14);  

//     // ----- SYNC & SIGNAL POLARITY -----
//     I2C_Write(0x15, 0x20);     // COM10: PCLK only at active href

//     // RGB565 output
//     I2C_Write(0x40, 0xD0);  

//     // Byte order: always 0x04 for RGB565
//     I2C_Write(0x3A, 0x05);  
//      I2C_Write(0x3D, 0x88);

//     // Enable auto-exposure, auto-gain, auto white balance
//    // I2C_Write(0x13, 0x8F);  

//     // ----- Scaling for QQVGA (downscale by 2 from QVGA) -----

//     I2C_Write(0x0C, 0x00);   // COM3: enable scaling
//     I2C_Write(0x3E, 0x12);   // COM14: manual scaling, divide by 2
//     I2C_Write(0x70, 0x30);   // SCALING_XSC
//     I2C_Write(0x71, 0x20);   // SCALING_YSC
//     I2C_Write(0x72, 0x22);   // SCALING_DCWCTR (downsample)
//     I2C_Write(0x73, 0x04);   // SCALING_PCLK_DIV (divide PCLK)
//  //   I2C_Write(0xA2, 0x02);   // PCLK automatic

//      // ----- AUTO EXPOSURE / AWB / AGC -----
//     I2C_Write(0x13, 0xAF);     // COM8: enable AGC, AWB, AEC
//     I2C_Write(0x14, 0x18);     // COM9: AGC gain ceiling = 4x

//     // ----- Use default windowing for QVGA -----
//     // (Do NOT modify registers 0x17–0x1A)

//     // Disable test pattern
//   //  I2C_Write(0x42, 0x00);
// }



// void ov7670_init_rgb565(void)
// {

//     RST_OV_Clear();
//     for(volatile int i=0; i<100000; i++);  // delay
//     RST_OV_Set();


//     // Reset all registers
//     I2C_Write(0x12, 0x80);     // COM7: Reset
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay
//     for(volatile int i=0; i<100000; i++);  // delay


//     // Clock config
//   //  I2C_Write(0x11, 0x80);     // CLKRC: no prescale (use full MCLK)

//     // ----- RGB565 OUTPUT -----
//     I2C_Write(0x12, 0x14);     // COM7: QVGA + RGB output
//    // I2C_Write(0x8C, 0x00);     // RGB444: disable
//    // I2C_Write(0x04, 0x00);     // COM1: no CCIR656
//     I2C_Write(0x40, 0xD0);     // COM15: RGB565, full range
//     I2C_Write(0x3A, 0x05);     // TSLB: correct RGB565 byte ordering
//     I2C_Write(0x3D, 0x88);

//     // ----- SCALING FOR QVGA -----
//     I2C_Write(0x3E, 0x19);     // COM14: manual scaling enable, divide by 2
//     I2C_Write(0x70, 0x3A);     // Scaling DCW CTR
//     I2C_Write(0x71, 0x35);     // Scaling PCLK divider
//     I2C_Write(0x72, 0x22);     // Scaling X
//     I2C_Write(0x73, 0xF2);     // Scaling Y
//     I2C_Write(0x0C, 0x04);     // COM3: enable scaling

//     // ----- WINDOWING (set active pixel region) -----
//     I2C_Write(0x17, 0x16);     // HSTART
//     I2C_Write(0x18, 0x04);     // HSTOP
//     I2C_Write(0x32, 0x80);     // HREF offset
//     I2C_Write(0x19, 0x02);     // VSTART
//     I2C_Write(0x1A, 0x7A);     // VSTOP
//     I2C_Write(0x03, 0x0A);     // VREF 

//     // ----- AUTO EXPOSURE / AWB / AGC -----
//    I2C_Write(0x13, 0xAF);     // COM8: enable AGC, AWB, AEC
//    I2C_Write(0x14, 0x18);     // COM9: AGC gain ceiling = 4x

//     // ----- SYNC & SIGNAL POLARITY -----
//     I2C_Write(0x15, 0x20);     // COM10: PCLK only at active href

//     // ----- Disable test patterns -----
// //    I2C_Write(0x42, 0x04);     // COM17: no color bar 

//     // COLOR MATRIX (CRITICAL)
//   //  I2C_Write(0x4F, 0x80);
//   //  I2C_Write(0x50, 0x80);
//     // I2C_Write(0x51, 0x00);
//     // I2C_Write(0x52, 0x22);
//     // I2C_Write(0x53, 0x5E);
//     // I2C_Write(0x54, 0x80);
//     // I2C_Write(0x56, 0x40);

//     // Gamma
//     //  I2C_Write(0x7C, 0x00);
//     //  I2C_Write(0x7D, 0x00);
//     //  I2C_Write(0x7D, 0x02);
//     //  I2C_Write(0x7D, 0x04);
//     // I2C_Write(0x7D, 0x08);
//     // I2C_Write(0x7D, 0x10);
//     // I2C_Write(0x7D, 0x20);
//     // I2C_Write(0x7D, 0x40);
//     // I2C_Write(0x7D, 0x80);

//     // Disable test patterns
//     //I2C_Write(0x42, 0x00);
// }


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );

    TCC1_PWMStart();


    RST_OV_Clear();
    for(volatile int i=0; i<100000; i++);  // delay
    RST_OV_Set();

    //ov7670_init_rgb565_correct();

//    ov7670_init_rgb565_basic();

    

    ov7670_set_rgb565_QQVGA_Working();
   // ov7670_init_qqvga_rgb565();
   // ov7670_init_rgb565();


//     uint8_t regs[] = {0x12,0x40,0x3A,0x13,0x3D,0x11,0x3E,0x0C,0x42,
//                   0x4F,0x50,0x51,0x52,0x53,0x54,0x56,
//                   0x70,0x71,0x72,0x73,0x74};

// for (int i=0;i<sizeof(regs);++i) {
//     I2C_Read(regs[i]);   // implement simple SCCB read
// }


           
           EIC_CallbackRegister(EIC_PIN_1, (EIC_CALLBACK)VSYNC_ISR, 0);
           EIC_CallbackRegister(EIC_PIN_2, (EIC_CALLBACK)HSYNC_ISR, 0);

           DMA_ChannelCallbackRegister(DMA_CHANNEL_1, DMA_EventHandler, 0);


   
    
   // DMA_Channel0(); 
   // DMA_Channel1();

  // capture_rgb565_fast();

 //  capture_rgb565_polling();

 //  capture_frame_polling();

   //capture_frame_y_only();


 //  send_frame();

    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );


         if(SWITCH1_Get () == 0)
        {
          while (SWITCH1_Get () == 0);
          TCC1_PWMStart();

         }

        if (frame_ready) {
            frame_ready = false;
           // TCC1_PWMStop();
            // process frame_buffer (display/store/convert)
            legato_showScreen(screenID_Screen0);
            // If sending via other DMA (to LCD), ensure caches are cleaned
            DCACHE_CLEAN_BY_ADDR((uint32_t *)panda_scaled_data, FRAME_BYTES);
        }

        //processCompletion();

        
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

