/*
 * Instance header file for PIC32CZ8110CA90208
 *
 * Copyright (c) 2024 Microchip Technology Inc. and its subsidiaries.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2024-07-31T17:51:00Z */
#ifndef _PIC32CZCA90_TCC3_INSTANCE_
#define _PIC32CZCA90_TCC3_INSTANCE_


/* ========== Instance Parameter definitions for TCC3 peripheral ========== */
#define TCC3_CC_NUM                              (2)        /* Number of Compare/Capture units */
#define TCC3_DITHERING                           (1)        /* Dithering feature implemented */
#define TCC3_DMAC_ID_MC_0                        (51)       /* Indexes of DMA Match/Compare triggers 0 */
#define TCC3_DMAC_ID_MC_1                        (52)       /* Indexes of DMA Match/Compare triggers 1 */
#define TCC3_DMAC_ID_OVF                         (50)       /* DMA overflow/underflow/retrigger trigger */
#define TCC3_DTI                                 (1)        /* Dead-Time-Insertion feature implemented */
#define TCC3_GCLK_ID                             (34)       /* Index of Generic Clock */
#define TCC3_INSTANCE_ID                         (36)       /* Instance index for TCC3 */
#define TCC3_MASTER_SLAVE_MODE                   (0)        /* TCC type 0 : NA, 1 : Master, 2 : Slave */
#define TCC3_MCLK_ID_APB                         (44)       /* Index for TCC3 APB clock */
#define TCC3_OTMX                                (1)        /* Output Matrix feature implemented */
#define TCC3_OW_NUM                              (2)        /* Number of Output Waveforms */
#define TCC3_PAC_ID                              (36)       /* Index for TCC3 registers write protection */
#define TCC3_PG                                  (1)        /* Pattern Generation feature implemented */
#define TCC3_SIZE                                (32)       
#define TCC3_SWAP                                (1)        /* DTI outputs swap feature implemented */

#endif /* _PIC32CZCA90_TCC3_INSTANCE_ */
