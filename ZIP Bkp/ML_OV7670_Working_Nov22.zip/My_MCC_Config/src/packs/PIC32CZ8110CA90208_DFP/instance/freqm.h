/*
 * Instance header file for PIC32CZ8110CA90208
 *
 * Copyright (c) 2024 Microchip Technology Inc. and its subsidiaries.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2024-07-31T17:51:00Z */
#ifndef _PIC32CZCA90_FREQM_INSTANCE_
#define _PIC32CZCA90_FREQM_INSTANCE_


/* ========== Instance Parameter definitions for FREQM peripheral ========== */
#define FREQM_GCLK_ID_MSR                        (3)        /* Index of measure generic clock */
#define FREQM_GCLK_ID_REF                        (4)        /* Index of reference generic clock */
#define FREQM_INSTANCE_ID                        (10)       /* Instance index for FREQM */
#define FREQM_MCLK_ID_APB                        (13)       /* Index for FREQM APB clock */
#define FREQM_MSRCLK_NB                          (2)        /* Number of measured clock sources */
#define FREQM_PAC_ID                             (10)       /* Index for FREQM registers write protection */

#endif /* _PIC32CZCA90_FREQM_INSTANCE_ */
